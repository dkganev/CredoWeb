<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> 
        Hospitals
     <?php $__env->endSlot(); ?>
    <?php echo $__env->make('CredoWeb.nav',  ['dataLink' => $dataLink], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container">
        <h1>Hospitals</h1>
    
    
        <div id="toolbar">
            <div class="form-inline" role="form">
                <button type="button" class="btn btn-primary" id="addBtn">ADD <i class="fa fa-plus" ></i></button>
            </div>
        </div>
        <table
            id="table"
            data-toolbar="#toolbar"
            data-show-columns="true"
            data-show-columns-toggle-all="true"
            data-pagination="true"
            data-page-list="[10, 25, 50, 100, all]"
            data-filter-control="true"
            data-show-search-clear-button="true">
            <thead >
                
                <tr>
                    <th class="text-center" data-field="id" data-sortable="true" data-filter-control="input">ID</th>
                    <th class="text-center" data-field="name" data-sortable="true" data-filter-control="input">Name</th>
                    <th class="text-center" data-field="addres" data-sortable="true" data-filter-control="input">Address</th>
                    <th class="text-center" data-field="phone" data-sortable="true" data-filter-control="input">Phone</th>
                    <th class="text-center" data-field="action" data-sortable="false" >Action</th>
                </tr>
    
            </thead>
            <tbody >
                        
                <?php $__currentLoopData = $dataHospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataHospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($dataHospital->ID); ?></td>
                        <td class="text-right"><?php echo e($dataHospital->name); ?></td>
                        <td class="text-right"><?php echo e($dataHospital->address); ?></td>
                        <td class="text-right"><?php echo e($dataHospital->phone); ?></td>
                        <td class="text-center">
                                <button type="button" onclick='openViewHospitalForm(<?php echo e($dataHospital->ID); ?>)' class="btn btn-success" data-dismiss="edit">View <i class="fa fa-eye"></i></button>
                                <button type="button" onclick='openEditHospitalForm(<?php echo e($dataHospital->ID); ?>)' class="btn btn-info" data-dismiss="edit">Edit <i class="fa fa-edit"></i></button>
                                <button type="button" onclick='deleteHospital(<?php echo e($dataHospital->ID); ?>)'class="btn btn-danger" data-dismiss="delete">Delete <i class="fa fa-trash-o"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>   

    </div>
        
    <?php echo $__env->make('CredoWeb.Hospitals.addHospitals',  [], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('CredoWeb.Hospitals.viewHospitals', [], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('CredoWeb.Hospitals.editHospitals', [], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/testLaminas/laravel/CredoWeb/CredoWeb/resources/views/CredoWeb/hospitals.blade.php ENDPATH**/ ?>