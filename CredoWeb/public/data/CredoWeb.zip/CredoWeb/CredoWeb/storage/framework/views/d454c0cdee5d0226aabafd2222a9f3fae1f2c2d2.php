<!--		<form method="POST" action="<?php echo e(url('/test23')); ?>">
            <?php echo csrf_field(); ?>
			
			<input type="text" id="lname1" name="lname1" value="Submit1"><br><br>
			
			<input type="text" id="lname2" name="lname2" value="Submit2"><br><br>
			
			<input type="text" id="lname3" name="lname3" value="Submit3"><br><br>
			
			<input type="submit" value="Submit">
			

            
        </form>

<!-- load jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

 <!-- provide the csrf token -->
 <!--   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

	<input class="getinfo"></input>
    <button class="postbutton" class="btn btn-success save-data">Post via ajax!</button>
    <div class="writeinfo"></div>
	-->
	<button class="postbutton222" onclick='testPostRoute()' class="btn btn-success save-data">Post via ajax!</button>
    
    <script>
	
/*$(".save-data").click(function(event){
		
		
	$.ajax({
        url: "/test24",
        type:"POST",
        data:{
          //name:name,
          //email:email,
          //mobile_number:mobile_number,
          //message:message,
          //_token: _token
        },
        success:function(response){
          console.log(response);
          if(response) {
            //$('.success').text(response.success);
            //$("#ajaxform")[0].reset();
          }
        },
    });
});
*/	
	
function testPostRoute() {
		console.log('test1234');
		
	$.ajax({
        url: "http://127.0.0.1:8000/rest3",
        type:"POST",
		dataType: 'JSON',
        data:{ 
			user: 'User', //'User', 'admin'
			pass: 'ieSV55Qc+eQOaYDRSha/AjzNTJE=',  // 'ieSV55Qc+eQOaYDRSha/AjzNTJE=',   'LGbG48dDRlYCxtzY6UEr7l+4Ru0='
			//isHungry: true
		
          //name:'name',
          //email:email,
          //mobile_number:mobile_number,
          //message:message,
          //_token: _token
        },
        success:function(response){
          console.log('111',response.success);
          if(response) {
            //$('.success').text(response.success);
            //$("#ajaxform")[0].reset();
          }
        },
		error:function(response){
          console.log('error',response);
          if(response) {
            //$('.success').text(response.success);
            //$("#ajaxform")[0].reset();
          }
        },
    });
    
		
  /*fetch(`/foo/${id}`, {
    method: 'POST',
    headers: {
      "Content-type": "application/json", // We are sending JSON data
      credentials: 'include'
    },
    body: JSON.stringify({ name: 'Eka', isHungry: true })
  })
    .then(function(response) {
      return response.json();
    })
    .then(function (payload) {
      console.log("API response", payload);
      // ... do other things here
    })*/
}

	
	
        $(document).ready(function(){
			console.log('test12');
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $(".postbutton").click(function(){
				/*$.ajax({url: "http://127.0.0.1:8001/test24", 
				success: function(result){
					console.log('test1');
					$("#div1").html(result);
				},
				error: function(result){
					console.log('error', result );
					//$("#div1").html(result);
				}
				
				});
				*/
                $.ajax({
                    /* the route pointing to the post function */
                    url: 'http://127.0.0.1:8001/test23',
                    type: 'POST',
                    /* send the csrf-token and the input to the controller */
                   data: {_token: CSRF_TOKEN, message:$(".getinfo").val()},
                    //dataType: 'JSON',
                    /* remind that 'data' is the response of the AjaxController */
                    success: function (data) { 
						console.log('test1', data.token ,' - ' , CSRF_TOKEN);
						tese24Token = data.token;
                        //$(".writeinfo").append('tet'); 
						$.ajax({
							/* the route pointing to the post function */
							url: 'http://127.0.0.1:8001/test24',
							type: 'POST',
							/* send the csrf-token and the input to the controller */
							data: {_token: tese24Token, message:$(".getinfo").val()},
							//dataType: 'JSON',
							/* remind that 'data' is the response of the AjaxController */
							success: function (data) { 
								console.log('test1', data.token ,' - ' , CSRF_TOKEN);
								//$(".writeinfo").append('tet'); 
							},
							error: function (data) { 
								console.log('error', data.responseJSON);
								//$(".writeinfo").append('tet'); 
							}
					
					
						});                   


				   },
					error: function (data) { 
						console.log('error', data.responseJSON);
					    //$(".writeinfo").append('tet'); 
                    }
					
					
                }); 
            });
       });    
    </script>

     <!-- <div id="div1"><h2>Let jQuery AJAX Change This Text</h2></div>
	 -->


<?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/rest/rest.blade.php ENDPATH**/ ?>