<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> 
        Links
     <?php $__env->endSlot(); ?>
    
    <div class="body-box " >
        <?php $__currentLoopData = $mainDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="main-box " href="<?php echo e($mainData['URL']); ?>" title="<?php echo e($mainData['title']); ?>">
                <div class="box1" style="border-color: <?php echo e($mainData['color']); ?>;" >
                    <div class="w-100 p-3">
                        <i class="fa fa-plus rounded-circle box2" style="color:<?php echo e($mainData['color']); ?>; border-color: <?php echo e($mainData['color']); ?>;"></i>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    
    
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/main.blade.php ENDPATH**/ ?>