<div class="modal-body">
    <div class="form-group">
        <div class="row">
            <div class="col-sm-4 text-right">
                <label><sup><i class="fa fa-asterisk" style="font-size: 10px; "></i></sup>Name:</label>
            </div>
            <div class="col-sm-4">
                <input class="form-control" type="text" name="name" placeholder="Name" value="">
            </div>    
        </div>
    </div>
    <div class="form-group">
        <div class="row">
            <div class="col-sm-4 text-right">
                <label><sup><i class="fa fa-asterisk" style="font-size: 10px; "></i></sup>Address:</label>
            </div>
            <div class="col-sm-4">
                <input class="form-control" type="text" name="address" placeholder="Address" value="">
            </div>    
        </div>
    </div>
    <div class="form-group">
        <div class="row">
            <div class="col-sm-4 text-right">
                <label><sup><i class="fa fa-asterisk" style="font-size: 10px; "></i></sup>Phone:</label>
            </div>
            <div class="col-sm-4">
                <input class="form-control" type="tel" name="phone" placeholder="Phone" value="">
            </div>    
        </div>
    </div>
</div><?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/CredoWeb/Hospitals/modalHospitals.blade.php ENDPATH**/ ?>