<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> 
        Users
     <?php $__env->endSlot(); ?>
    <?php echo $__env->make('CredoWeb.nav',  ['dataLink' => $dataLink], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container">
        <h1>Users</h1>
    
    
        <div id="toolbar">
            <div class="form-inline" role="form">
                <button type="button" class="btn btn-primary" id="addBtn">ADD <i class="fa fa-plus" ></i></button>
            </div>
        </div>
        <table
            id="table"
            data-toolbar="#toolbar"
            data-show-columns="true"
            data-show-columns-toggle-all="true"
            data-pagination="true"
            data-page-list="[10, 25, 50, 100, all]"
            data-filter-control="true"
            data-show-search-clear-button="true">
            <thead >
                
                <tr>
                    <th class="text-center" data-field="id" data-sortable="true" data-filter-control="input">ID</th>
                    <th class="text-center" data-field="first_name" data-sortable="true" data-filter-control="input">First Name</th>
                    <th class="text-center" data-field="last_name" data-sortable="true" data-filter-control="input">Last Name</th>
                    <th class="text-center" data-field="email" data-sortable="true" data-filter-control="input">Email</th>
                    <th class="text-center" data-field="type" data-sortable="true" data-filter-control="select">Type</th>
                    <th class="text-center" data-field="workplace" data-sortable="true" data-filter-control="input">Workplace</th>
                    <th class="text-center" data-field="created_at" data-sortable="true" data-filter-control="input">Created</th>
                    <th class="text-center" data-field="action" data-sortable="false" >Action</th>
                </tr>
    
            </thead>
            <tbody >
                        
                <?php $__currentLoopData = $dataUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($dataUser->ID); ?></td>
                        <td class="text-right"><?php echo e($dataUser->first_name); ?></td>
                        <td class="text-right"><?php echo e($dataUser->last_name); ?></td>
                        <td class="text-right"><?php echo e($dataUser->email); ?></td>
                        <td class="text-right"><?php echo e($dataUser->type); ?></td>
                        <td class="text-right"><?php echo e($dataUser->name); ?></td>
                        <td class="text-right"><?php echo e($dataUser->created_at); ?></td>
                        <td class="text-center">
                                <button type="button" onclick='openEditUserForm(<?php echo e($dataUser->ID); ?>)' class="btn btn-success" data-dismiss="edit">Edit <i class="fa fa-edit"></i></button>
                                <button type="button" onclick='deleteUser(<?php echo e($dataUser->ID); ?>)'class="btn btn-danger" data-dismiss="delete">Delete <i class="fa fa-trash-o"></i></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>   

    </div>
<?php echo $__env->make('CredoWeb.Users.addUsers',  ['dataTypes' => $dataTypes, 'dataHospitals' => $dataHospitals], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('CredoWeb.Users.editUsers', ['dataTypes' => $dataTypes, 'dataHospitals' => $dataHospitals], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

  

<script>
//        $(function() {
//            $('#table').bootstrapTable()
//        })

//$(document).ready(function(){
//  $("#addBtn").click(function(){
//    $("#addModal").modal();
//  });
//});
</script>  
   



<?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/CredoWeb/users.blade.php ENDPATH**/ ?>