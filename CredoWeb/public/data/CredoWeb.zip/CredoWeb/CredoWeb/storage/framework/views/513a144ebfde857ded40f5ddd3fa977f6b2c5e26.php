<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title'); ?> 
        Modal
     <?php $__env->endSlot(); ?>
    <input type="hidden" id="ID"  value="<?php echo e($ID); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    <div class="body-box " >
        <div class="row">
            <div class="form-group">
                <label class="col-sm-4" >Title:</label>
                <input type="text" id="name" class="col-sm-4" value="<?php echo e($linksData['Name']); ?>">
            </div>
            
        </div>
        <div class="row">
            <div class="form-group">
                <label class="col-sm-4" >Link:</label>
                <input type="url" name="url" id="url" placeholder="https://example.com" value="<?php echo e($linksData['URL']); ?>" class="col-sm-4" >
            </div>
            
        </div>
        <div class="row">
            <div class="form-group">
                <label class="col-sm-4" >Color:</label>
                <select class="col-sm-4" id="color" onchange="" value="<?php echo e($linksData['Color_ID']); ?>">
                    <option value="0"></option>
                    <?php $__currentLoopData = $dataColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dataColor->ID); ?>" <?php echo e($dataColor->ID == $linksData['Color_ID'] ? 'selected' : ''); ?> ><?php echo e($dataColor->color); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </select>
      
            </div>
            
        </div>
        <div class="row">
            <div class="form-group col-sm-8" style=" text-align: right">
                <button  onclick='updateData()' class="btn btn-success save-data">Update</button>
            </div>
        </div>
    </div>
    
    
<script>
    function testPostRoute(UserID) {
		console.log('test1234', UserID);
                //var x = document.getElementById("mySelect").value;
                //document.getElementById("demo").innerHTML = "You selected: " + x;
                $("select").change(function(){
                    $("select").v
                });
                
    }
    
    

		
    
</script>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/testLaminas/laravel/blog2/resources/views/modal.blade.php ENDPATH**/ ?>