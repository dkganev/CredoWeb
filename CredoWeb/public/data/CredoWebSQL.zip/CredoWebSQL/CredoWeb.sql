-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 18, 2021 at 12:02 PM
-- Server version: 8.0.23-0ubuntu0.20.04.1
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CredoWeb`
--
CREATE DATABASE IF NOT EXISTS `CredoWeb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `CredoWeb`;

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `ID` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(200) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`ID`, `name`, `address`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'test11', 'Sofia', '0889 222 222', '2021-04-17', '2021-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `ID` int NOT NULL,
  `email` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `type` int NOT NULL COMMENT '1 is patient, 2 is  doctor',
  `workplace_id` int DEFAULT NULL COMMENT 'only IF a user is type doctor',
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`ID`, `email`, `first_name`, `last_name`, `type`, `workplace_id`, `created_at`, `updated_at`) VALUES
(1, 'dkganev@abv.bg', 'Dimitar', 'Ganev', 2, 1, '2021-04-16', '2021-04-16'),
(2, 'perar@gmail.com', 'Petar', 'Petrov', 2, 1, '2021-04-15', '2021-04-17'),
(3, 'Ivo@test.com', 'Ivo', 'Ivo', 1, NULL, '2021-04-16', '2021-04-17'),
(5, 'sss@ddd.bg', 'eee', 'eee', 1, NULL, '2021-04-17', '2021-04-17'),
(6, 'Vlado@test.bg', 'Vlado', 'Vlado', 1, NULL, '2021-04-17', '2021-04-17'),
(7, 'rrr@eee.bd', 'ppp', 'rrr', 1, NULL, '2021-04-17', '2021-04-17');

-- --------------------------------------------------------

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
